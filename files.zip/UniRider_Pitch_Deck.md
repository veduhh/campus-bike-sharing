# UniRider – Ride Smart. Save Time. Stay Green.

---

## 1️⃣ Title Slide
- **App Name**: UniRider
- **Tagline**: Ride Smart. Save Time. Stay Green.
- **Team Members**: [List Names]
- **University Name**: [Your University]
- **Graphics**: Bike icon, solar panel, map pin, greenery background

---

## 2️⃣ Problem Statement
- Many students & faculty struggle to reach classes/meetings on time.
- Walking long distances across campus is tiring and time-consuming.
- Late arrivals = lost learning time & stress.

*Image*: Frustrated student, campus map with long paths.

---

## 3️⃣ Solution – UniRider
- On-campus bike-sharing, accessible via a smart app.
- Quick, eco-friendly, and affordable rides between university blocks.

*Graphic*: Student scanning bike QR code, happy faces.

---

## 4️⃣ Key Features
- _Login/Sign-Up_: Secure university credentials
- _Dashboard_: Rides, stats, credits
- _Map_: Real-time bikes, routes, campus navigation
- _Ride Stats_: Speed, distance, calories, ETA
- _Payments_: Pay-per-ride or memberships

*Icons*: Lock, dashboard, map, stats, wallet

---

## 5️⃣ Membership Options
- **Weekly**: Unlimited rides for the week
- **Monthly**: Discounted rates for frequent users
- **Pay-as-you-go**: Flexible for casual riders

*Table*: Compare each option with price & benefits.

---

## 6️⃣ Competitive Dashboard
- Weekly leaderboard:
  - 🚴‍♀️ Distance traveled
  - 🔥 Calories burned
  - 🏁 Number of rides

*Graphic*: Leaderboard with avatars, bars

---

## 7️⃣ Safety & Support
- **SOS Button**: For emergencies/breakdowns
- **Maintenance Request**: Report issues instantly
- **24/7 support**: Chat or call

*Icons*: SOS, wrench, headset

---

## 8️⃣ Eco-Friendly Tech
- **Solar-powered docks** ☀️
- **Smart IoT locks**
- **Reduced carbon emissions**

*Infographic*: Solar → bike → tree/clean air

---

## 9️⃣ App Interface Overview
- Screenshots/Mockups:
  - Login
  - Dashboard (with menu)
  - Map (route, speed, time)
  - Payment/Membership

*Tip*: Use Figma or Canva for mockups.

---

## 🔟 Revenue Model
- Memberships, per-ride fees
- Campus sponsorships
- App/dock ad banners

*Icons*: Coins, sponsor logo, ad banner

---

## 1️⃣1️⃣ SDG Alignment
- **SDG 11**: Sustainable Cities & Communities
- **SDG 13**: Climate Action

*Logos*: UN SDGs, green city

---

## 1️⃣2️⃣ Conclusion
- UniRider = Easier, faster, greener campus travel
- Promotes fitness & environmental care

**“Pedal towards a greener, smarter campus.”**

---

### Design Tips:
- Use a soft green/blue palette (#2ecc71, #27ae60, #48c9b0, #f4f9f4)
- Clean, modern sans-serif fonts (Montserrat, Lato)
- Minimalist icons throughout
- Slide transitions: Fade or morph